---
tutorial: "https://www.youtube.com/watch?v=KqO8ebdqs5I"
---

# `17`  Russian Roulette

¿Has jugado a la ruleta rusa? ¡Es muy divertido! Si no pierdes... (¡¡¡muuuajajajaja!!!).

Un revolver tiene seis recámaras para balas... inserta una bala en una de las recámaras, gira el tambor del revolver para hacer aleatorio el juego. Nadie sabrá dónde está la bala.

¡¡¡FUEGO!!!...... ¿Has muerto?

## 📝 Instrucciones: 

1. El juego casi funciona, por favor completa la función `fire_gun` para que el juego funcione. 

2. Compara la posición de la bala con la posición de la recámara. 

3. Si la posición de la bala es igual a la posición de la recámara, entonces la función debe retornar `You are dead!`, de lo contrario, debe retornar `Keep playing!`

## 💡 Pistas: 

- Puedes obtener la posición de la recámara llamando a la función `spin_chamber`.
  
- Si la bala está en el mismo compartimento que la recámara del revólver, entonces será disparada (`You are dead!`).
