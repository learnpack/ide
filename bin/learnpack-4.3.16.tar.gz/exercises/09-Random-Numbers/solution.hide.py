import random

def get_randomInt():
	# ✅ ↓ CHANGE ONLY THIS ONE LINE BELOW ↓ ✅
	random_number = random.randint(1,10)
	return random_number

print(get_randomInt())