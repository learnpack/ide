def is_odd(my_number):
  	return (my_number % 2 != 0)


def my_main_code():
    # ✅ ↓ Your code here ↓ ✅