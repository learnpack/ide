# print "Hello World!" on the console

print("Hello World!")