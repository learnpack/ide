age = int(input('What is your age?\n'))
# ✅ ↓ CHANGE THE CODE BELOW TO ADD 10 TO AGE ↓ ✅
age = age + 10
print("Your age is: "+str(age))
