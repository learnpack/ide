---
tutorial: "https://www.youtube.com/watch?v=zeWN4ujg6yU"
---

# `05` User Inputed Values

The other cool thing about variables is that you don't need to know their value to be able to work with them.

For example, the application right now is prompting the user for its age, and then printing it on the console.

## 📝 Instructions:

1. Please add 10 years to the value of the age variable.

## 💡 Hints:

+ You can Google "how to add a number to a Python variable".

+ Remember that the content of the variable is being previously filled with whatever the user inputs.
