---
tutorial: "https://www.youtube.com/watch?v=0-vljraNvwE"
---

# `13` Your First Loop

## 📝 Instrucciones:

1. Ejecuta este código, verás una cuenta de 0 a 9. 

2. Corrígelo para que cuente hasta 11.

## 🔎 Importante: 

+ Hay una serie de ejercicios dedicados a listas y bucles, te invitamos a realizarlos antes de continuar: [https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises](https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises). 

¡Luego, regresa! 😊

## 💡 Pista:
+ Puedes encontrar información adicional aquí: https://tutorial.recursospython.com/bucles/
