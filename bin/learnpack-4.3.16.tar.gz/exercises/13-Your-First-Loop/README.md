---
tutorial: "https://www.youtube.com/watch?v=30sizcnVdGg"
---

# `13` Your First Loop

## 📝 Instructions:

1. Run this code, and you'll see a count from 0 to 9.  

2. Fix it so that it counts up to 11.

## 🔎 Important: 

+ There's a series of exercises dedicated to Lists and Loops, we encourage you to go and finish those before continuing: [https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises](https://github.com/4GeeksAcademy/python-lists-loops-programming-exercises).

Then, come back! 😊

## 💡 Hint:
+ You can find additional information on loops here: https://www.w3schools.com/python/python_for_loops.asp
