def standards_maker():
    # ✅↓ Write your code here ↓✅
    for i in range(0, 300):
        print("I will ask questions if I am stuck")

# ✅↓ remember to call the function outside (here) ↓✅
standards_maker()
