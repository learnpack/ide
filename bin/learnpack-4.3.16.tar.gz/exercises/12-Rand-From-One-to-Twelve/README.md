---
tutorial: "https://www.youtube.com/watch?v=EdyMlVlNUT0"
---

# `12` Rand From One to Twelve

## 📝 Instructions:

1. Change whatever you need to change to make the algorithm print random integers between 1 and 12. 

2. This time use the `randrange()` function.

## 💡 Hints:

+ It should print between 1 and 12, not between 0 and 12.

+ This exercise is super simple, don't complicate yourself! 😃
