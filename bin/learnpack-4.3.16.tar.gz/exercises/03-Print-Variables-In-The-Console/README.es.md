---
tutorial: "https://www.youtube.com/watch?v=SM71mzjuvfA"
---

# `03` Print more Variables in The Console

También puedes imprimir más de una variable en la misma función `print()` separando con una coma `,` las variables a imprimir. De esta manera:

```py
my_variable = 'hello'
my_second_variable = "world"
print(my_variable, my_second_variable)  # --> hello world
```

## 📝 Instrucciones:

1. Declara dos nuevas variables llamadas `color` y `item` y asígnales el valor `"red"` y `marker` respectivamente.

2. Luego, imprime sus valores en la consola (puede que tengas que desplazarte en la consola para poder verlo).
