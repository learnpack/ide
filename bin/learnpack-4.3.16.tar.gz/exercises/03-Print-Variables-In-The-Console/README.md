# `03` Print more Variables in the console

You can also print more than one variable in the same `print()` function by separating the variables with a comma `,`. Like this:

```py
my_variable = 'hello'
my_second_variable = "world"
print(my_variable, my_second_variable)  # --> hello world
```

## 📝 Instructions:

1. Declare two new variables called `color` and `item`, and assign the value `"red"` and `"marker"` respectively to it.

2. Then, print their values on the console (you may have to scroll up in the terminal to see it!).
