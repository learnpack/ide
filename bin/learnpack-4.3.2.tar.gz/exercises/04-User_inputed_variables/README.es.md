---
tutorial: "https://www.youtube.com/watch?v=2W-f9F0vu7w"
---

# `04` User Inputted Variables

La otra cuestión genial sobre las variables es que no necesitas saber su valor para poder trabajar con ellas.

Por ejemplo, esta aplicación solicita al usuario su edad. Veamos si podemos cambiarla.

## 📝 Instrucciones:

1. Por favor añade/suma 10 años al valor de la variable `age`. 

2. Imprime el resultado en la consola.


## 💡 Pista:

+ El contenido de la variable está determinado por las entradas del usuario. La función `prompt()` guarda el valor ingresado como un string. 

+ Debes asegurarte de que la variable esté convertida en un número entero para que el cálculo sea correcto. Esta es una buena oportunidad para trabajar tu capacidad para resolver problemas buscando en Google.
