function getRandomInt()
{
	let randomNumber = Math.floor(Math.random() * 10) + 1;
	return randomNumber;
}


console.log(getRandomInt());
