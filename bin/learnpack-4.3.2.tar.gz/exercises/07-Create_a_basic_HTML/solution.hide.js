const a = '</title>';
const b = '</html>';
const c = '<head>';
const d = '</body>';
const e = '<html>';
const f = '</head>';
const g = '<title>';
const h = '<body>';

//Modify this variable
let htmlDocument = e+c+g+a+f+h+d+b;

console.log(htmlDocument);