let button = document.getElementById("superDuperButton");
button.addEventListener("click", function() {
	// Your code here

});
