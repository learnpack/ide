---
tutorial: "https://www.youtube.com/watch?v=hs0WuLzXWa4"
---


# `10` Add li on Click

## 📝 Instrucciones:

1. Usando la función `createElement`, agrega un nuevo elemento `<li>` a `#myList` cada vez que se haga clic en el `#superDuperButton`.

## 💻 Resultado Esperado:

![Gif del resultado esperado](../../.learn/assets/11-1.gif)

## 💡 Pistas:

+ Obtén el botón `#superDuperButton` con la función `getElementById`.

+ Agrega un listener de eventos de *click* al `#superDuperButton`.

+ Dentro de esa función de listener, agrega el código necesario para crear el nuevo elemento `<li>` y añádelo a la lista como hijo.
