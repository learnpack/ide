//Set the values here
let myVar1 = '';
let myVar2 = '';

//Don't change any code below
let theNewString = myVar1+' '+myVar2;
console.log(theNewString);