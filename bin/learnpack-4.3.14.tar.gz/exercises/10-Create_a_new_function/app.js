function shortIntroduction() {
  // Complete this function's body and arguments
  
}

// Fill the gaps with your data in the correct order
console.log(shortIntroduction(" ", " ", " "))