const VERSION = '0.1';

VERSION = '0.9';

console.log(VERSION);