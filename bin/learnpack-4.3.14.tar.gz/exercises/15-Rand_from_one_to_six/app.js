function getRandomInt()
{
	let randomNumber = Math.random();
	return randomNumber;
}
console.log(getRandomInt());