---
intro: "https://www.youtube.com/watch?v=32WbSowUcjc"
---

![Javascript Preview](../../.learn/assets/i-love-javascript.jpeg?raw=true)

# Bienvenido a los Ejercicios de JavaScript!

Este es el primero de una serie de tutoriales interactivos orientados a entregarte todos los conocimientos necesarios para tener éxito en el mundo de JavaScript.

## Aprenderás: 

- `console.log`
- Concatenación de string
- Arrays
- Funciones
- Loops
- ¡Y mucho más!

Presiona el botón de `Next →` en la esquina superior derecha de la pantalla cuando estés listo para empezar los ejercicios.
