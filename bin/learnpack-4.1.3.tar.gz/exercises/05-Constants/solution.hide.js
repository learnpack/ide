// const VERSION = '0.1';

const VERSION = '0.9';

console.log(VERSION);