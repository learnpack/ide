---
intro: "https://www.youtube.com/watch?v=GjQEotj3t6Y"
---

![Javascript Preview](../../.learn/assets/i-love-javascript.jpeg?raw=true)

# Welcome to the JavaScript Exercises!

This is the first in a series of interactive tutorials meant to provide everything you need to start your journey into the world of JavaScript.

## You will learn:

- `console.log()` 
- String concatenation 
- Arrays 
- Functions 
- Loops
- And much more!

Click `Next →` on the top right side of the screen when you are ready to start.
