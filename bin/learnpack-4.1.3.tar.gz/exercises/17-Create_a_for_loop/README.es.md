# `17` Creating a `for` loop

Como ya aprendimos, los bucles son muy útiles para repetir una tarea rápida y eficientemente usando muy pocas líneas de código. Mientras continúas en tu travesía para convertirte en desarrollador, el bucle `for` se convertirá en una herramienta indispensable.

Esta es la estructura de un bucle `for`:

```js
for (expresionInicial; condicional; expresionIncremental) {
    ...declaraciones;
}
```

Aquí hay un ejemplo de la declaración `for`:

```js
// Un bucle "for"
for (let i = 0; i < 10; i++) {
    console.log("Hello!")
}
```

Queremos asegurarnos de que has comprendido que hacer preguntas es importante para tu desarrollo como programador. 

## 📝 Instrucciones:

1. Escribe 300 veces `I will write questions if I'm stuck` ¡Afortunadamente ya conoces una forma rápida de hacerlo! (usando un bucle `for`).

2. Crea una función llamada `standardsMaker()` que imprima 300 veces la frase `I will write questions if I'm stuck`.

## 💡 Pistas:

+ Lee más acerca de bucles aquí: https://www.w3schools.com/js/js_loop_for.asp
