function fizzBuzz() {  
	// Your code here
}

fizzBuzz();