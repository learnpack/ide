let age = prompt('What is your age?');

// Your code below:
