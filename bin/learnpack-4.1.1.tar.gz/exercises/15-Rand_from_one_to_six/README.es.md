# `15` Random numbers from one to six

## 📝 Instrucciones:

1. ¡Bien! Ahora cambia lo que sea que necesites cambiar para hacer que el algoritmo imprima números enteros aleatorios entre 1 y 6.

## 💡 Pistas:

+ Debería imprimir entre 1 y 6, no entre 0 y 6.

+ Este ejercicio es super sencillo, no te compliques...