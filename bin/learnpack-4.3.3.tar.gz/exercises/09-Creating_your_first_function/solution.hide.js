function addNumbers(a,b){
	// This is the function's body. Write your code here.
	return a + b
}

//Do not change the code below
console.log(addNumbers(3,4));
