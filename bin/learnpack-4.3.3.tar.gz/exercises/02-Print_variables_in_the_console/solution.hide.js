let mySuperVariable = 'hello';
console.log(mySuperVariable);

// your code below
let color = 'red';
console.log(color)