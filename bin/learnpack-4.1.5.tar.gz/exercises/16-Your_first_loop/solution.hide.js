/* Done - check tests and clear for student use */

for (let i = 0; i <= 100; i++) {
	console.log(i)
}