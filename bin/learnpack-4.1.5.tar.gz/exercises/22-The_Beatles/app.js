

//Your code above ^^^

console.log(sing());