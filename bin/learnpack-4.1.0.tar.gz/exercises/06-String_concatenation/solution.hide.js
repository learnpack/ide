//Set the values here
let myVar1 = 'Hello';
let myVar2 = 'World';

//Don't change any code below
let theNewString = myVar1+' '+myVar2;
console.log(theNewString);