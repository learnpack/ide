let total = prompt('How many km are left to go?');

// Your code below:
