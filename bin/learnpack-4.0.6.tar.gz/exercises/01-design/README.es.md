
# `01` Design

Vamos a construir este postcard (postal) con HTML/CSS:

![Poscard Preview](../../assets/thumb.png?raw=true)

[Haz clic aquí para ver la imagen más grande](https://raw.githubusercontent.com/breatheco-de/exercise-postcard/86dcbe572cfad6a40b1909025a2fdaa63d76919c/.learn/assets/preview.png?raw=true)

Haz clic en el botón `next ➡` en la esquina superior derecha de la pantalla para ir a las siguientes instrucciones. 
