
# `01` Design

We are going to be building this postcard in HTML/CSS:

![Poscard Preview](../../assets/thumb.png?raw=true)

[Click here to open a bigger picture](https://raw.githubusercontent.com/breatheco-de/exercise-postcard/86dcbe572cfad6a40b1909025a2fdaa63d76919c/.learn/assets/preview.png?raw=true)

Click on the `next ➡` button on the upper right corner of the screen to go to the next instructions.
