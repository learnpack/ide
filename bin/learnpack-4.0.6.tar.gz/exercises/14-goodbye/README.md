# `14` Goodbye

## You did it, your postcard is ready! 👏

The HTML is at 100%, maybe you can add a few more styles to make it look even better. You can keep playing with them to make your postcard look even more similar to the given example ;)

> If you have questions remember to ask using [4Geeks Academy's Slack channel](https://4geeksacademy.slack.com/), and here is my twitter [alesanchezr](https://twitter.com/alesanchezr).
