# `14` Goodbye

## ¡Lo lograste, tu postcard está lista! 👏

El HTML está al 100%, tal vez puedas añadir algunos estilos más para que se vea aún mejor. Puedes seguir jugando con ellos para que tu postcard se vea incluso más similar al ejemplo dado ;)

> Si tienes alguna pregunta, puedes hacerlas a través de Slack [4Geeks Academy's Slack channel](https://4geeksacademy.slack.com/), y aquí tienes mi twitter [alesanchezr](https://twitter.com/alesanchezr).
