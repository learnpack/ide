# `03` Add first HTML

Nuestro archivo está vacío; los archivos `.html` deben tener `<tags>` (etiquetas) HTML.

Un `<tag>` HTML es simplemente una oración que comienza y termina con la misma palabra.

### Ejemplo:

```html
<strong>Cualquier cosa</strong>
```

> `<strong>` es un tag HTML utilizado para que el texto esté en negrita (más grueso).

## 📝 Instrucciones:

1. Añade dentro de tu archivo `index.html` el código HTML que aparece en el ejemplo.
