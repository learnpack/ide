# `03` Add first HTML

Our file is currently empty; `.html` files must be filled with HTML `<tags>`.

An HTML `<tag>` is just a sentence that starts and ends with the same word.

### Example:

```html
<strong>Anything</strong>
```

> `<strong>` is an HTML tag used to make the text bold (more thick).

## 📝 Instructions: 

1. Add into your `index.html` file the HTML code of the example.
