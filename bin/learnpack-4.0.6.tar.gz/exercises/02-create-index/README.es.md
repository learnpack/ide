# `02` Create Index

Todos los sitios web en el mundo deben comenzarse con un archivo llamado `index.html`, al crearlo manualmente el computador lo reconocerá como el `entry point` (punto de entrada) de tu aplicación.

## 📝 Instrucciones:

1. Por favor, crea un archivo llamado `index.html` en la raíz del proyecto.

## 💡 Pista:

+ Debes ser cuidadoso porque el nombre del archivo debe ser exactamente ese.
