---
tutorial: https://www.youtube.com/watch?v=-ewDD9VJE80
---

# `02` Create Index

All websites in the world must start with a file called `index.html`, when you manually create it, the computer will recognize it as the `entry point` of your application.

## 📝 Instructions:

1. Please create a file called `index.html` on the root of the project.

## 💡 Hint:

+ Be very careful because the name of the file has to be exact.

