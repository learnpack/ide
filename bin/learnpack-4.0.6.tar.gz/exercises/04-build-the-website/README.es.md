# `04` Build the website

¡Es hora de revisar cómo se ven los cambios en tu sitio web!

## 📝 Instrucciones:

1. Haz clic en botón `Run` en la esquina superior izquierda, sobre las instrucciones, para ver tu website en vivo. 

## 💡 Pista: 

![Run button](../../assets/run-button.png) 

## 🔎 Importante:

+ Puedes hacerlo cuantas veces quieras. Te recomendamos hacerlo cada vez que hagas cambios, de esa forma puedes verificar tu progreso.
