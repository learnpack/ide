# `04` Build the website

Now it's time to see how your changes look like on your website!

## 📝 Instructions:

1. Click the `Run` button in the upper left corner, above the instructions, to see your website live.

## 💡 Hint:

![Run button](../../assets/run-button.png) 

## 🔎 Important:

+ You can build as many times as you want, we recommend you to do it every time you make changes, that way you can check your progress as you go.
