---
tutorial: "https://www.youtube.com/watch?v=3LDGpTlLe_w"
---

# `02` Print Variables to the Console

You can also use the `console.log()` function to print variables in the console. It is a great way to know their content, like this:

## 📝 Instructions:

1. Declare a new variable called `color` and assign the value `"red"` to it.

2. Print its value to the console.

## 📎 Example:

```js
let mySuperVariable = 'hello';
console.log(mySuperVariable);
```
