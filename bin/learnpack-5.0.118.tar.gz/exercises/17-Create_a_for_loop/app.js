// Declare and write your function here:


standardsMaker();