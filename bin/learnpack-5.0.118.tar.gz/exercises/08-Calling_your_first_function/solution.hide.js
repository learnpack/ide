function isOdd(myNumber)
{
	return !(myNumber % 2 == 0);
}

// Your code below:
console.log(isOdd(45345))