// Your code here
document.body.innerHTML = `<img src="https://via.placeholder.com/350x150"/>`;
