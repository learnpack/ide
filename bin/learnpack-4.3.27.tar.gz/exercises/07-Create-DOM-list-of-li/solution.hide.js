let beginning = "<ul>";
let listString = "<li>First Item</li><li>Second Item</li><li>Third Item</li>";
let ending = "</ul>";

// Do not modify after this line
document.body.innerHTML = beginning + listString + ending;
