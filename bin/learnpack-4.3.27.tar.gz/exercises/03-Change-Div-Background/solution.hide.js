let myDiv = document.querySelector("#myDiv");
// Your code here
myDiv.style.background = "yellow"
