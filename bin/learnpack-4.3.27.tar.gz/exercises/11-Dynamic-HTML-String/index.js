let myString = "<p>Hello!</p> <strong>My friend</strong>, ";
document.write(myString);