// Your code here
let list = document.querySelector('#parentLi');
let secondLi = list.childNodes[3];
list.removeChild(secondLi);
