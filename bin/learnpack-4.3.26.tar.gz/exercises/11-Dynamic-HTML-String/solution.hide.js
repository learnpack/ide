let myString = "<p>Hello!</p> <strong>My friend</strong>, we are in the year " + new Date().getFullYear();
document.write(myString);
