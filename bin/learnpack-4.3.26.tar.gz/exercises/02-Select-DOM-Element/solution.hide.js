// Your code here
let aux = document.querySelector('#theTitle');
alert(aux.id);
