# `01` Hello World

The DOM is where all your front-end knowledge combines, you need to know a little bit of HTML, CSS and JavaScript.

But everything starts with a Hello World, of course 😄

## 📝 Instructions:

1. This exercise contains one HTML, one CSS and one JS file. Please open your JS file and fill it with the code to prompt an alert saying `Hello World`.

## 💡 Hints:

+ Build and preview your exercise code. It will open in a new window.

+ Press the test button when you feel comfortable enough to automatically grade it. Once you are ready, do the next one!
