---
tutorial: "https://www.youtube.com/watch?v=T3I448FYqWY"
---


# `01` Hello World

EL DOM es donde se combinan todos tus conocimientos de front-end, debes conocer un poco de HTML, CSS y JavaScript.

Pero todo comienza con un Hello World, por supuesto. 😄

## 📝 Instrucciones:

1. Este ejercicio contiene un archivo HTML, un CSS y un archivo JS, abre tu archivo JS y complétalo con el código para generar una alerta con `Hello World`.

## 💡 Pistas:

+ Compila y obtén una vista previa del código del ejercicio. Se abrirá en una nueva ventana.

+ Presiona el botón de test cuando te sientas lo suficientemente cómodo para calificarlo automáticamente y pasar al siguiente ejercicio.
