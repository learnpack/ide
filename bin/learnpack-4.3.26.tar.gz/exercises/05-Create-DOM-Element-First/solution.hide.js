// Your code here
let p = document.createElement("p");
p.innerHTML = "Hello World";
p.style.background = "yellow";

document.body.appendChild(p);
