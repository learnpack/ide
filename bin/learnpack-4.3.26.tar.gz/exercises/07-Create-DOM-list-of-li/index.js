let beginning = "<ul>";
let listString = "";
let ending = "</ul>";

// Do not modify after this line
document.body.innerHTML = beginning + listString + ending;
