---
tutorial: "https://www.youtube.com/watch?v=-klOOsBeBSg"
---


# `04` Move DOM Element 

Puedes cambiar cualquiera de las propiedades CSS cuando lo desees. CSS tiene algunas propiedades que definen la posición de un objeto, esto quiere decir que podemos usar JavaScript para cambiar la posición de un objeto.

## 📝 Instrucciones:

1. En este ejercicio, el `<div>` con id `#wulu` está flotando (`float`) a la izquierda por defecto. Usando JavaScript, cambia la propiedad CSS `float` y haz que flote a la derecha (`right`).

## 💡 Pista:

+ http://www.w3schools.com/jsref/prop_style_cssfloat.asp
