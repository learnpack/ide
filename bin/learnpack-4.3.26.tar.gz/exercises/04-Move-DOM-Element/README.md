# `04` Move DOM Element

You can change any of the CSS properties whenever you want. CSS has some properties that define the position of an object, which means you can use JavaScript to change the position of an object.

## 📝 Instructions:

1. In this exercise, the `<div>` with id `#wulu` is floating to the left by default. Using JavaScript, please change the `float` CSS property and make it `float` to the `right`.

## 💡 Hint:

+ http://www.w3schools.com/jsref/prop_style_cssfloat.asp
