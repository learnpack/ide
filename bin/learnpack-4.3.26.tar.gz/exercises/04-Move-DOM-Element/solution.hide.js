let aux = document.querySelector("#wulu");
// Your code here
aux.style.float = "right"
