let aux = document.querySelector("#wulu");
// Your code here
