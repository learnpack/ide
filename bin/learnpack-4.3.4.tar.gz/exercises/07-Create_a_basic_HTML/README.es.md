---
tutorial: "https://www.youtube.com/watch?v=cIC82hNEZ00"
---

# `07` Creating Basic HTML Code

Continuemos utilizando concatenación de strings para generar HTML. El código de la izquierda contiene 8 constantes con diferentes valores de string.

## 📝 Instrucciones:

1. Concatena las constantes. 

2. Establece el valor de la variable `htmlDocument` en un nuevo string que tenga el típico contenido de un documento HTML (con las etiquetas de HTML en el orden correcto).

3. Asígnale el valor de la variable `htmlDocument` a este nuevo string e imprime su valor en la consola.

## 💡 Pista:

+ El resultado debería verse así:

```js
<html><head><title></title></head><body></body></html>
```
