function addNumbers(a,b){
	// This is the function's body. Write your code here.
	
}

//Do not change the code below
console.log(addNumbers(3,4));
