// Declare and write your function here:
function standardsMaker() {
    for (let i = 0; i < 300; i++) {
        console.log("I will write questions if I'm stuck")
    }
}

standardsMaker();