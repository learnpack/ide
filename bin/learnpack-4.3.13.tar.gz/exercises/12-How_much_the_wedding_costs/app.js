let guests = prompt('How many people are coming to your wedding?');

function getPrice(guests){
    let cost = 0;
    // Your code here
 

    return cost;
}

let price = getPrice(guests);
console.log('Your wedding will cost '+price+' dollars');
