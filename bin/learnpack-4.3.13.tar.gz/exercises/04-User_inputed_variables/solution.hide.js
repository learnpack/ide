let age = prompt('What is your age?');

// Your code below:

let result = parseInt(age) + 10
console.log(result);