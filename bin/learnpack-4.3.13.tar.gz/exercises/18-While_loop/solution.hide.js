//fix this function:
function startCounting() {
	let counter = 101;
	while (counter > 0) {
		counter--;
		console.log(counter);
	}

	return counter;
}

startCounting();