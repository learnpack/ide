//fix this function:
function startCounting() {
	let counter = 100;
	while (counter <= 100) {
		counter--;
		console.log(counter);
	}

	return counter;
}

startCounting();