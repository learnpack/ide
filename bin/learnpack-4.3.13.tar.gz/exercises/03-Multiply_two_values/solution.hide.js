// Your code below:
let variablesAreCool=2345*7323
console.log(variablesAreCool)