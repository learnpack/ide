---
tutorial: "https://www.youtube.com/watch?v=49LFfe9Du58"
---

# `02` Print Variables to the Console

También puedes utilizar la función `console.log()` para imprimir variables en la consola. Es una buena forma para saber su contenido.

## 📝 Instrucciones:

1. Declara una nueva variable llamada `color` y asígnale el valor `"red"`.

2. Luego, imprime su valor en la consola.

## 📎 Ejemplo:

```js
let mySuperVariable = 'hello';
console.log(mySuperVariable);
```
