let mySuperVariable = 'hello';
console.log(mySuperVariable);

// your code below
