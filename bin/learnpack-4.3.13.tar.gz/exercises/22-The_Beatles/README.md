# `22` The Beatles 

Who doesn't like The Beatles? A BBC study reported that 90% of kids today don't know the band. Heartbreaking... 😟

Below is the chorus of one of the most famous Beatles songs, *Let It Be*:

> Let it be, let it be, let it be, let it be

> Whisper words of wisdom

> Let it be

## 📝 Instructions:

1. Create a function called `sing()` that returns a string with the exact same lyrics which you can hear from the 3:20 mark to the end of the song at 3:50. 

## 💻 Expected output: 

```js
"let it be, let it be, let it be, let it be, there will be an answer, let it be, let it be, let it be, let it be, let it be, whisper words of wisdom, let it be"
```

## 💡 Hints:

+ The words `let it be` are repeated in the string. Creating a loop would be a good idea.

+ Here is the song: https://www.youtube.com/watch?v=QDYfEBY9NM4
