# `022` The Beatles 

¿A quién no le gustan Los Beatles? Un estudio de la BBC ha mostrado que el 90% de los niños de ahora no conocen la banda... Qué triste... 😟

Abajo está el coro de una de las canciones más famosas de Los Beatles, *Let it be*:

> Let it be, let it be, let it be, let it be

> Whisper words of wisdom

> Let it be

## 📝 Instrucciones:

1. Crea una función llamada `sing()` que devuelva un string con la letra exacta que puedes oír desde el minuto 3:20 hasta el final de la canción a los 3:50 minutos. 

## 💻 Resultado esperado:

```js
"let it be, let it be, let it be, let it be, there will be an answer, let it be, let it be, let it be, let it be, let it be, whisper words of wisdom, let it be"
```

## 💡 Pistas:

+ Las palabras `let it be` se repiten todo el tiempo, probablemente debas crear un bucle (loop) para eso.

+ Aquí está la canción: https://www.youtube.com/watch?v=QDYfEBY9NM4
