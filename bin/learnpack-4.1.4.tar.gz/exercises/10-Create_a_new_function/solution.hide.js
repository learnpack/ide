function shortIntroduction(name, profession, age) {
    // Complete this function's body and arguments
    return "Hello! my name is " + name + ", my profession is " + profession + ". I am " + age + " years old."
}
  
// Fill the gaps with your data in the correct order
console.log(shortIntroduction("Trinity", "Developer", "35"))