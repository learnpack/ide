# `15` Random numbers from one to six

## 📝 Instructions:

1. Okay! Now change whatever you need to change in order to make the algorithm print random integers between 1 and 6.

## 💡 Hints:

+ It should print between 1 and 6, not between 0 and 6.

+ This exercise is super simple, don't overcomplicate things...
